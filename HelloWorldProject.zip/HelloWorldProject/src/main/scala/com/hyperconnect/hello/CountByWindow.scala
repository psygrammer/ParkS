package com.hyperconnect.hello

import java.sql.Timestamp

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.streaming.Trigger

/**
  * Created by ohjaehyeuk on 2017. 8. 19..
  */
object CountByWindow {
  def main(args: Array[String]): Unit = {

    val spark = SparkSession
      .builder
      .appName("HCHelloWorld")
      .getOrCreate()

    import spark.implicits._
    import org.apache.spark.sql.functions._

    val lines = spark.readStream
      .format("socket")
      .option("host", "localhost")
      .option("port", 9999)
      .option("includeTimestamp", true)
      .load()

    val words = lines.as[(String, Timestamp)].flatMap(line =>
      line._1.split(" ").map(word => (word, line._2))
    ).toDF("word", "timestamp")
    val wordCount = words.groupBy(
      window($"timestamp", "1 minutes", "1 minutes"),  // windowDuration, slideDuration
      $"word"
    ).count()

    val query = wordCount.writeStream
      .trigger(Trigger.ProcessingTime("10 seconds"))  // trigger by 10 seconds
      .outputMode("complete")
      .format("console")
      .option("truncate", "false")
      .option("numRows", 1000)
      .start()

    query.awaitTermination()
  }

}
