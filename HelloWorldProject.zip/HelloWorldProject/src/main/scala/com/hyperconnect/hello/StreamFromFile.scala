package com.hyperconnect.hello

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType

/**
  * Created by ohjaehyeuk on 2017. 8. 19..
  */
object StreamFromFile {
  def main(args: Array[String]): Unit = {
    if (args.length < 1) {
      System.err.println("Usage: StreamFromFile <filepath>")
      System.exit(1)
    }

    val filepath = args(0)

    val spark = SparkSession
      .builder()
      .appName("HCHelloWorld")
      .getOrCreate()

    val userSchema = new StructType().add("name", "string").add("age", "integer")
    val words = spark.readStream
      .schema(userSchema)
      .format("json")
      .load(filepath)

    words.printSchema()

    val names = words.select("name") // projection
    val sumAge = words.groupBy("name").sum("age") // aggregation
    val persons = words.select("*").where("age >= 20") // selection

    val query = persons
      .writeStream
      .outputMode("update")  // outputMode : update
      .format("console")
      .start()

    query.awaitTermination()

  }
}
