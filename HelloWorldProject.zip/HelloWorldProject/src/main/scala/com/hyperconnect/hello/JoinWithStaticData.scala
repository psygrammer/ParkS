package com.hyperconnect.hello

import java.sql.Timestamp

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.streaming.Trigger

/**
  * Created by ohjaehyeuk on 2017. 8. 20..
  */
object JoinWithStaticData {
  case class Customer(name: String, id: String, paid: String, age:String)
  def main(args: Array[String]): Unit = {

    val spark = SparkSession
      .builder
      .appName("HCHelloWorld")
      .getOrCreate()

    import spark.implicits._

    val customerDs = spark.read
      .format("json")
      .option("header", false)
      .load("/Users/ohjaehyeuk/HelloWorldProject/static/customers.json")
      .as[Customer]

    val linesDs = spark.readStream
      .format("socket")
      .option("host", "localhost")
      .option("port", 9999)
      .option("includeTimestamp", true)
      .load()

    val nameDs = linesDs
      .as[(String, Timestamp)]
      .toDF("name", "timestamp")

    val joinedDs = nameDs
      .join(
        customerDs,
        nameDs.col("name").equalTo(customerDs.col("name")),
        "left_outer")

    val query = joinedDs
      .writeStream
      .trigger(Trigger.ProcessingTime("10 seconds"))  // trigger by 10 seconds
      .outputMode("append")
      .format("console")
      .option("truncate", "false")
      .option("numRows", 1000)
      .start()

    query.awaitTermination()
  }
}
