package com.hyperconnect.hello

import java.sql.Timestamp

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType

/**
  * Created by ohjaehyeuk on 2017. 8. 20..
  */
object RecoveringWithCheckpointing {
  def main(args: Array[String]): Unit = {
    if (args.length < 1) {
      System.err.println("Usage: StreamFromFile <filepath>")
      System.exit(1)
    }

    val filepath = args(0)
    println(filepath)

    val spark = SparkSession
      .builder()
      .appName("HCHelloWorld")
      .getOrCreate()

    val userSchema = new StructType().add("name", "string").add("age", "integer")
    val words = spark.readStream
      .schema(userSchema)
      .format("json")
      .load(filepath)

    words.printSchema()

    val noAggDF = words.select("name", "age").where("age > 20")
    val sumAge = words.groupBy("name").sum("age") // for complete (recovery 지원하지 않음)

    val query = noAggDF.writeStream
      .outputMode("append")
      .option("checkpointLocation", "/Users/ohjaehyeuk/HelloWorldProject/checkpoint")
      // .format("console")
      .partitionBy("name")  // partition by columnName
      .format("csv") // append mode 만 지원합니다
      .option("path", "/Users/ohjaehyeuk/HelloWorldProject/output")
      .start()

    query.awaitTermination()

  }
}
