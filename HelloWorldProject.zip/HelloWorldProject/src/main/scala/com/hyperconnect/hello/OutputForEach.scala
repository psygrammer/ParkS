package com.hyperconnect.hello

import java.sql.Timestamp

import org.apache.spark.sql.{Row, ForeachWriter, SparkSession}

/**
  * Created by ohjaehyeuk on 2017. 8. 20..
  */
object OutputForEach {
  def main(args: Array[String]): Unit = {

    val spark = SparkSession
      .builder
      .appName("HCHelloWorld")
      .getOrCreate()

    import spark.implicits._
    import org.apache.spark.sql.functions._

    val lines = spark.readStream
      .format("socket")
      .option("host", "localhost")
      .option("port", 9999)
      .option("includeTimestamp", true)
      .load()

    val words = lines.as[(String, Timestamp)].flatMap(line =>
      line._1.split(" ").map(word => (word, line._2))
    ).toDF("word", "timestamp")
    val wordCount = words
      .withWatermark("timestamp", "2 minutes")
      .groupBy(
        window($"timestamp", "2 minutes", "1 minutes"),
        $"word"
      )
      .count()

    val query = wordCount.writeStream
      .outputMode("update")
      .foreach(new ForeachWriter[Row] {
        def open(partitionId: Long, version: Long): Boolean = {
          print(s"\npartitionId:${partitionId}, version:${version}")
          true
        }

        def process(record: Row) = {
          print("\nprocess:" + record.mkString(", "))
        }

        def close(errorOfNull: Throwable): Unit = {
          print("\nclose")
        }
      })
      .start()

    query.awaitTermination()
  }
}
