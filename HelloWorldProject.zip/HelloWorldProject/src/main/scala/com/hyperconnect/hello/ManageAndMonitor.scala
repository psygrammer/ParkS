package com.hyperconnect.hello

import java.sql.Timestamp

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.streaming.StreamingQueryListener
import org.apache.spark.sql.streaming.StreamingQueryListener.{QueryStartedEvent, QueryTerminatedEvent, QueryProgressEvent}

/**
  * Created by ohjaehyeuk on 2017. 8. 20..
  */
object ManageAndMonitor {
  def main(args: Array[String]): Unit = {

    val spark = SparkSession
      .builder
      .appName("HCHelloWorld")
      .getOrCreate()

    spark.streams.addListener(new StreamingQueryListener() {
      override def onQueryStarted(queryStarted: QueryStartedEvent): Unit = {
        println("Query started: " + queryStarted.id)
      }
      override def onQueryTerminated(queryTerminated: QueryTerminatedEvent): Unit = {
        println("Query terminated: " + queryTerminated.id)
      }
      override def onQueryProgress(queryProgress: QueryProgressEvent): Unit = {
        //println("Query made progress: " + queryProgress.progress)
      }
    })

    import spark.implicits._
    import org.apache.spark.sql.functions._

    val lines = spark.readStream
      .format("socket")
      .option("host", "localhost")
      .option("port", 9999)
      .option("includeTimestamp", true)
      .load()

    val words = lines.as[(String, Timestamp)].flatMap(line =>
      line._1.split(" ").map(word => (word, line._2))
    ).toDF("word", "timestamp")
    val wordCount = words.groupBy(
      window($"timestamp", "2 minutes", "1 minutes"),
      $"word"
    ).count()

    val query = wordCount.writeStream
      .outputMode("complete")
      .format("console")
      .start()

    while(true) {
      query.explain()
      println(query.lastProgress)
      println(query.status)

      Thread sleep 5000
    }
  }

}
